//
// Created by braydendstone on 2/25/18.
//

#include "Expression.h"

Expression::Expression(std::shared_ptr<Types> type) : type(type)
{
    isConst = false;
}
Expression::Expression(std::shared_ptr<Types> type, int value, bool isConst, int offset) : type(type), value(value), isConst(isConst), memOffset(offset)
{}
