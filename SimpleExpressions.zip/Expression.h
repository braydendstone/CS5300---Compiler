//
// Created by braydendstone on 2/25/18.
//

#ifndef CPSL_EXPRESSION_H
#define CPSL_EXPRESSION_H


#include "Types.h"
#include "RegPool.h"
#include <memory>
#include <iostream>

class Expression {

private:
    bool isConst = false;
    int value = 0;
    std::shared_ptr<Types> type = nullptr;
    std::string reg;
    int memOffset = 0;

public:
    explicit Expression(std::shared_ptr<Types> type);
    Expression(std::shared_ptr<Types> type, int value, bool isConst, int offset = 0);
//    ~Expression(){ RegPool::returnReg(reg); }
    int getOffset() { return memOffset; }
    bool isExprConst() { return isConst; }
    int getVal() { return value; }
    std::string getReg() {
        if(reg == "")
        {
            reg = RegPool::allocate();

            if (type == GetTypes::boolType() || type == GetTypes::intType() || type == GetTypes::charType()) {
                std::cout << "lw " << reg << ", " << getOffset() << "($gp)" << std::endl;
            } else std::cout << "la " << reg << ", " << getOffset() << "($gp)" << std::endl;
        }
        return reg;
    }
    std::shared_ptr<Types> getType() { return type; }
    void setType(std::shared_ptr<Types> newType) { type = newType; }

};


#endif //CPSL_EXPRESSION_H
