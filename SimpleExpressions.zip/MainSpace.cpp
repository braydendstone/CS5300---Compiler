//
// Created by braydendstone on 2/23/18.
//

#include <iostream>
#include "MainSpace.h"

std::shared_ptr<GlobalSymbolTable> MainSpace::globalSymbolTable;

void MainSpace::setupProgram()
{
    std::cout << ".globl main" << std::endl;
    std::cout << ".code" << std::endl;
    std::cout << "main:" << std::endl;
//    std::cout << "main: la $gp, GA" << std::endl;
    std::cout << "j start" << std::endl;
    std::cout << "start: " << std::endl;

//    Expression* expr = strExpr("hello");
//    insertConst("x", expr);
//    auto pr = writeExpr(nullptr, expr);
//    write(pr);



}

std::shared_ptr<GlobalSymbolTable> MainSpace::initTable()
{
    auto globalTable = std::make_shared<GlobalSymbolTable>();
    globalTable->enter_scope();

    // ***** INSTANTIATE AND INSERT PREDEFINED TYPES *****


    globalTable->storeType("integer", GetTypes::intType());
    globalTable->storeType("INTEGER", GetTypes::intType());
    globalTable->storeType("char", GetTypes::charType());
    globalTable->storeType("CHAR", GetTypes::charType());
    globalTable->storeType("string", GetTypes::strType());
    globalTable->storeType("STRING", GetTypes::strType());
    globalTable->storeType("boolean", GetTypes::boolType());
    globalTable->storeType("BOOLEAN", GetTypes::boolType());

    // TODO: add bool true = 1 false = 0

//    auto trueExpr = std::make_shared<Expression>(GetTypes::boolType(), true);
//    globalSymbolTable->storeConst("true", trueExpr);
//    globalSymbolTable->storeConst("TRUE", trueExpr);
//
//    auto falseExpr = std::make_shared<Expression>(GetTypes::boolType(), false);
//    globalSymbolTable->storeConst("false", falseExpr);
//    globalSymbolTable->storeConst("FALSE", falseExpr);

    globalTable->enter_scope(); //TODO: do this at BEGIN instead?

    RegPool::initialize();
    return globalTable;
}

void MainSpace::start(int body)
{
    std::cout << ".data" << std::endl;
    std::cout << ".asciiz" << std::endl;
    getSymbolTable()->printStringList();
//    std::cout << "GA:" << std::endl;
}

std::shared_ptr<GlobalSymbolTable> MainSpace::getSymbolTable()
{
    if(!globalSymbolTable) {
        globalSymbolTable = initTable();
        insertConst("true", new Expression(GetTypes::boolType(), 1, true));
        insertConst("TRUE", new Expression(GetTypes::boolType(), 1, true));
        insertConst("false", new Expression(GetTypes::boolType(), 0, true));
        insertConst("FALSE", new Expression(GetTypes::boolType(), 0, true));
    }
    return globalSymbolTable;
}

void MainSpace::insertConst(std::string id, Expression* e)
{
    getSymbolTable()->storeConst(id, std::make_shared<Expression>(e->getType(), e->getVal(), true));
}

void MainSpace::insertVar(std::vector<std::string>* list, Types* type)
{
    auto idType = getSymbolTable()->lookupType(type->getName());
    for(auto v : *list)
    {
        getSymbolTable()->storeVariable(v, idType);
    }
}

void MainSpace::insertType(std::string id, Types* type)
{
    auto idType = getSymbolTable()->lookupType(type->getName());

    getSymbolTable()->storeType(id, idType);

}

Expression* MainSpace::strExpr(std::string str)
{
    int strId = getSymbolTable()->storeString(str);
    auto expression = new Expression(GetTypes::strType(), strId, true);
    return expression;
}

Expression* MainSpace::intExpr(int i)
{
    auto expression = new Expression(GetTypes::intType(), i, true);
    return expression;
}

Expression* MainSpace::charExpr(char c)
{
    auto expression = new Expression(GetTypes::charType(), int(c), true);
    return expression;
}

Types* MainSpace::obtainType(std::string name)
{
    auto type = getSymbolTable()->lookupAllType(name);
    if(type == nullptr)
    {
        throw std::runtime_error("undefined type " + name);
    }

    return type.get();
}

Expression* MainSpace::lookup(std::string id)
{
//    try {
    auto tryConst = getSymbolTable()->lookupConst(id);
    if(tryConst != nullptr) {
        return tryConst.get();
    }
    else{
        auto tryVar = getSymbolTable()->lookupVar(id);
        if(tryVar != nullptr)
        {
            auto tryVarTranslate = tryVar.get();
            return new Expression(tryVarTranslate->getType(), 0, false, tryVarTranslate->getMemOffset());
        }
        else {
            return nullptr;
        }
    }

//    } catch (...)
//    {
//        auto tryVar = getSymbolTable()->lookupVar(id);
//        auto tryVarTranslate = tryVar.get();
//        return new Expression(tryVarTranslate->getType(), tryVarTranslate->getMemOffset());
//    }

    //TODO: try function/proc

}

void MainSpace::assign(Expression* lval, Expression* expr)
{
    if(lval->isExprConst())
    {
        throw std::runtime_error("cannot assign new value to const expression");
    }
    if(lval->getType() != expr->getType())
    {
        throw std::runtime_error("invalid assignment: types incompatible");
    }
    if(expr->isExprConst()) {
        auto reg = RegPool::allocate();
        if (expr->getType() == GetTypes::strType()) {
                std::cout << "la " << reg << ", STR" << expr->getVal() << std::endl;
            } else {
                std::cout << "li " << reg << ", " << expr->getVal() << std::endl;
            }
            std::cout << "sw " << reg << ", " << lval->getOffset() << "($gp)" << std::endl;
        }
    else {
        auto reg = expr->getReg();
        std::cout << "sw " << reg << ", " << lval->getOffset() << "($gp)" << std::endl;
    }


    delete lval;
    delete expr;
}


Expression* MainSpace::binaryop(std::string sym, Expression* a, Expression* b)
{
    Expression* result = nullptr;

    if(a->getType() != b->getType())
    {
        throw std::runtime_error("types not compatible");
    }
    if(a->isExprConst() && b->isExprConst())
    {
        return constFold(sym, a, b);
    }
    if(sym == "slt" || sym == "sgt" || sym == "sle" || sym == "sge" || sym == "seq" || sym == "sne")
    {
        result = new Expression(GetTypes::boolType());
    }
    else
    {
        result = new Expression(GetTypes::intType());
    }
    if(a->isExprConst() && !(b->isExprConst()))
    {
        auto reg = RegPool::allocate();
        auto reg2 = RegPool::allocate();
        auto reg3 = result->getReg();
        std::cout << "lw " << reg2 << ", " << b->getOffset() << "($gp)" << std::endl;
        std::cout << "li " << reg << ", " << a->getVal() << std::endl;
        std::cout << sym << " " << reg3 << ", " << reg << ", " << reg2 << std::endl;
        //std::cout << "sw " << reg3 << ", " << a->getOffset() << "($gp)" << std::endl;
        RegPool::returnReg(reg);
        RegPool::returnReg(reg2);
    }
    else if(!(a->isExprConst()) && b->isExprConst())
    {
        auto reg = RegPool::allocate();
        auto reg2 = RegPool::allocate();
        auto reg3 = result->getReg();
        std::cout << "lw " << reg2 << ", " << a->getOffset() << "($gp)" << std::endl;
        std::cout << "li " << reg << ", " << b->getVal() << std::endl;
        std::cout << sym << " " << reg3 << ", " << reg2 << ", " << reg << std::endl;
        //std::cout << "sw " << reg3 << ", " << a->getOffset() << "($gp)" << std::endl;
        RegPool::returnReg(reg);
        RegPool::returnReg(reg2);
    }
    else
    {
        auto reg = RegPool::allocate();
        auto reg2 = RegPool::allocate();
        auto reg3 = result->getReg();
        std::cout << "lw " << reg << ", " << a->getOffset() << "($gp)" << std::endl;
        std::cout << "lw " << reg2 << ", " << b->getOffset() << "($gp)" << std::endl;
        std::cout << sym << " " << reg3 << ", " << reg << ", " << reg2 << std::endl;
        //std::cout << "sw " << reg3 << ", " << a->getOffset() << "($gp)" << std::endl;
        RegPool::returnReg(reg);
        RegPool::returnReg(reg2);

        //TODO: it is storing it back in and it shouldn't be, need to load from register on print
    }

    return result;
}

Expression* MainSpace::constFold(std::string sym, Expression* a, Expression* b)
{
    Expression* result = nullptr;
    if(sym == "add")
    {
        result = new Expression(GetTypes::intType(), a->getVal() + b->getVal(), true);
    }
    if(sym == "sub")
    {
        result = new Expression(GetTypes::intType(), a->getVal() - b->getVal(), true);
    }
    if(sym == "mul")
    {
        result = new Expression(GetTypes::intType(), a->getVal() * b->getVal(), true);
    }
    if(sym == "div")
    {
        result = new Expression(GetTypes::intType(), a->getVal() / b->getVal(), true);
    }
    if(sym == "rem")
    {
        result = new Expression(GetTypes::intType(), a->getVal() % b->getVal(), true);
    }
    if(sym == "or")
    {
        result = new Expression(GetTypes::boolType(), a->getVal() | b->getVal(), true);
    }
    if(sym == "and")
    {
        result = new Expression(GetTypes::boolType(), a->getVal() & b->getVal(), true);
    }
    if(sym == "seq")
    {
        result = new Expression(GetTypes::boolType(), a->getVal() == b->getVal(), true);
    }
    if(sym == "sne")
    {
        result = new Expression(GetTypes::boolType(), a->getVal() != b->getVal(), true);
    }
    if(sym == "sle")
    {
        result = new Expression(GetTypes::boolType(), a->getVal() <= b->getVal(), true);
    }
    if(sym == "sge")
    {
        result = new Expression(GetTypes::boolType(), a->getVal() >= b->getVal(), true);
    }
    if(sym == "slt")
    {
        result = new Expression(GetTypes::boolType(), a->getVal() < b->getVal(), true);
    }
    if(sym == "sgt")
    {
        result = new Expression(GetTypes::boolType(), a->getVal() > b->getVal(), true);
    }

    return result;
}

void MainSpace::read(std::vector<Expression*>* list)
{
    for(auto e: *list)
    {
        if(e->isExprConst())
        {
            throw std::runtime_error("cannot read value into const");
        }
        else {
            if(e->getType() == GetTypes::intType())
            {
                std::cout << "li $v0, 5" << std::endl;
                std::cout << "syscall" << std::endl;
                std::cout << "sw $v0, " << e->getOffset() << "($gp)" << std::endl;
            }
            else if(e->getType() == GetTypes::charType())
            {
                std::cout << "li $v0, 12" << std::endl;
                std::cout << "syscall" << std::endl;
                std::cout << "sw $v0, " << e->getOffset() << "($gp)" << std::endl;
            } else{
                throw std::runtime_error("only integer and character types may be read");
            }
        }
    }
}

void MainSpace::write(std::vector<Expression*>* list) {

    for(auto e : *list)
    {
        if(e->getType() == GetTypes::intType())
        {
            if(e->isExprConst()) {
                std::cout << "li $a0, " << e->getVal() << std::endl;
            }
            else {
                auto reg = e->getReg();
                std::cout << "move $a0, " << reg << std::endl;
            }

            std::cout << "li $v0, 1" << std::endl;
        }
        else if(e->getType() == GetTypes::charType())
        {
            if(e->isExprConst()) {
                std::cout << "li $a0, " << e->getVal() << std::endl;
            }
            else {
                std::cout << "lw $a0, " << e->getOffset() <<"($gp)" << std::endl;
            }
            std::cout << "li $v0, 11" << std::endl;

        }
        else if(e->getType() == GetTypes::strType())
        {
            if(e->isExprConst()) {
                std::cout << "la $a0, STR" << e->getVal() << std::endl;
            }
            else {
                auto reg = e->getReg();
                std::cout << "move $a0, " << reg << std::endl;
            }
            std::cout << "li $v0, 4" << std::endl; // TODO: GET THE RIGHT CODE

        }
        else if(e->getType() == GetTypes::boolType())
        {
            if(e->isExprConst()) {
                std::cout << "li $a0, " << e->getVal() << std::endl; //TODO: FIX THIS
            }
            else {
                auto reg = e->getReg();
                std::cout << "move $a0, " << reg << std::endl;
            }
            std::cout << "li $v0, 1" << std::endl;

        } else {
            throw std::runtime_error("Invalid type: cannot print");
        }

        std::cout << "syscall" << std::endl;
    }
}

std::vector<Expression*>* MainSpace::exprList(std::vector<Expression*>* list, Expression* e)
{
    if(list == nullptr)
    {
        list = new std::vector<Expression*>();
    }

    list->push_back(e);
    return list;
}

std::vector<std::string>* MainSpace::identList(std::vector<std::string>* list, std::string str)
{
    if(list == nullptr)
    {
        list = new std::vector<std::string>();
    }

    list->push_back(str);
    return list;
}

Expression* MainSpace::chrConvert(Expression* e)
{
    if(e->getType() != GetTypes::intType())
    {
        throw std::runtime_error("char conversion only valid for int type");
    }

    Expression* result = new Expression(GetTypes::charType(), e->getVal(), e->isExprConst());

    return result;
}

Expression* MainSpace::ordConvert(Expression* e)
{
    if(e->getType() != GetTypes::charType())
    {
        throw std::runtime_error("int conversion only valid for char type");
    }

    Expression* result = new Expression(GetTypes::intType(), e->getVal(), e->isExprConst());

    return result;
}

void MainSpace::stopProgram()
{
    std::cout << "li $v0, 10" << std::endl;
    std::cout << "syscall" << std::endl;
}
