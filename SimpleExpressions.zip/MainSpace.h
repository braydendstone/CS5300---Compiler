//
// Created by braydendstone on 2/23/18.
//

#ifndef CPSL_MAINSPACE_H
#define CPSL_MAINSPACE_H

#include <string>
#include <memory>
#include "GlobalSymbolTable.h"
#include "Types.h"
#include "RegPool.h"

class MainSpace {
private:
    static std::shared_ptr<GlobalSymbolTable> globalSymbolTable;

public:
    static void setupProgram();
    static void start(int body);
    static std::shared_ptr<GlobalSymbolTable> initTable();

    static std::shared_ptr<GlobalSymbolTable> getSymbolTable();

    static void insertConst(std::string id, Expression* e);
    static void insertVar(std::vector<std::string>* list, Types* type);
    static void insertType(std::string id, Types* type);

    static Expression* strExpr(std::string);
    static Expression* intExpr(int i);
    static Expression* charExpr(char c);
    static std::vector<std::string>* identList(std::vector<std::string>* list, std::string str);

    static Types* obtainType(std::string);

    static Expression* lookup(std::string id);
    static void assign(Expression* a, Expression* b);
    static Expression* binaryop(std::string symbol, Expression* a, Expression* b);
    static Expression* constFold(std::string sym, Expression* a, Expression* b);

    static void read(std::vector<Expression*>* list);
    static void write(std::vector<Expression*>* list);
    static std::vector<Expression*>* exprList(std::vector<Expression*>* list, Expression* e);

    static Expression* chrConvert(Expression* e);
    static Expression* ordConvert(Expression* e);


    static void stopProgram();

};


#endif //CPSL_MAINSPACE_H
