//
// Created by braydendstone on 2/25/18.
//

#ifndef CPSL_TYPES_H
#define CPSL_TYPES_H

#include <string>
#include <memory>
#include <bits/shared_ptr.h>

class Types {
public:
    Types() = default;
    virtual int getSize() = 0;
    virtual std::string getName() = 0;
};

class IntegerType : public Types {
public:
    int getSize() { return 4; }
    std::string getName() { return "integer"; }
};

class CharacterType : public Types {
public:
    int getSize() { return 4; }
    std::string getName() { return "char"; }
};

class StringType : public Types {
public:
    int getSize() { return 4; }
    std::string getName() { return "string"; }
};

class BooleanType : public Types {
public:
    int getSize() { return 4; }
    std::string getName() { return "boolean"; }
};

class GetTypes {
public:
    static std::shared_ptr<Types> intType();
    static std::shared_ptr<Types> charType();
    static std::shared_ptr<Types> strType();
    static std::shared_ptr<Types> boolType();

private:
    static std::shared_ptr<Types> intPtr;
    static std::shared_ptr<Types> charPtr;
    static std::shared_ptr<Types> strPtr;
    static std::shared_ptr<Types> boolPtr;
};




#endif //CPSL_TYPES_H
