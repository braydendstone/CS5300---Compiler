//
// Created by braydendstone on 2/25/18.
//

#include "Types.h"

std::shared_ptr<Types> GetTypes::intPtr;
std::shared_ptr<Types> GetTypes::charPtr;
std::shared_ptr<Types> GetTypes::strPtr;
std::shared_ptr<Types> GetTypes::boolPtr;

std::shared_ptr<Types> GetTypes::intType()
{
    if(!intPtr) {
        intPtr = std::make_shared<IntegerType>();
    }

    return intPtr;
}

std::shared_ptr<Types> GetTypes::charType()
{
    if(!charPtr) {
        charPtr = std::make_shared<CharacterType>();
    }

    return charPtr;
}

std::shared_ptr<Types> GetTypes::strType()
{
    if(!strPtr) {
        strPtr = std::make_shared<StringType>();
    }

    return strPtr;
}

std::shared_ptr<Types> GetTypes::boolType()
{
    if(!boolPtr) {
        boolPtr = std::make_shared<BooleanType>();
    }

    return boolPtr;
}